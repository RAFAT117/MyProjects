package com.example.notepad_rafaat;


import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.Toast;
import java.util.HashSet;

public class NoteActivity extends AppCompatActivity {
    int NewNote;



    // save button and don't save button on menu 24-52
    @Override
    public boolean onCreateOptionsMenu(Menu menu) { // get menu from save_menu

        MenuInflater menuinflater = getMenuInflater();
        menuinflater.inflate(R.menu.save_menu, menu);
        return super.onCreateOptionsMenu(menu); }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) { //save button
        int id = item.getItemId();
        if ( id == R.id.saveButton) {

            SharedPreferences sharedPreferences = getApplicationContext().getSharedPreferences("com.example.notepad_rafaat", Context.MODE_PRIVATE);
            HashSet<String> set = new HashSet<>(MainActivity.notes);
            sharedPreferences.edit().putStringSet("notes",set).apply();
            MainActivity.arrayAdapter.notifyDataSetChanged();

            onBackPressed();
            Toast.makeText(this, "SAVED", Toast.LENGTH_SHORT).show();
            return true;
        }

        if (item.getItemId() == R.id.dont_saveButton) { //don't save/ undo changes button
            startActivity(new Intent(getApplicationContext(), MainActivity.class));
            finish();
            Toast.makeText(this, "NOT SAVED", Toast.LENGTH_SHORT).show();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_note);
        EditText editText = findViewById(R.id.editText);

        Intent intent = getIntent();
        NewNote = intent.getIntExtra("NewNote", -1); // value at -1 because main.activity starts at 0

        if (NewNote != -1) {

            editText.setText(MainActivity.notes.get(NewNote)); // getting the value of the notes text and display in the edit text if theres one
        } else {
            // if not add new note
            MainActivity.notes.add("");
            NewNote= MainActivity.notes.size() -1;
            MainActivity.arrayAdapter.notifyDataSetChanged();
        }


        editText.addTextChangedListener(new TextWatcher() {

            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {


            }

            @Override
            public void afterTextChanged(Editable editable) {

                MainActivity.notes.set(NewNote, String.valueOf(editable)); //update the "notes" array list from main.activity


            }

        });

    }

    @Override
    public void onBackPressed() {

        MainActivity.arrayAdapter.notifyDataSetChanged(); // updates something has changed /  update the list listview
        SharedPreferences sharedPreferences = getApplicationContext().getSharedPreferences("com.example.notepad_rafaat", Context.MODE_PRIVATE);
        HashSet<String> set = new HashSet<>(MainActivity.notes); // set for the notes
        sharedPreferences.edit().putStringSet("notes",set).apply(); // save the set in sharedPreference
        Toast.makeText(this, "SAVED", Toast.LENGTH_SHORT).show();

        super.onBackPressed();
    }
}
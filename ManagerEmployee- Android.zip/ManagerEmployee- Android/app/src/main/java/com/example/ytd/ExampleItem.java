package com.example.ytd;

public class ExampleItem {
    private final String Id;
    private final String Date;
    private final String salary;
    private final String name;



    public ExampleItem(String line1, String line2, String line3, String line4) {
        Id = line1;
        Date = line2;
        salary = line3;
        name = line4;
    }


    // Return value
    public String getLine1() {return "Id: "+Id;}
    public String getLine2() {return Date;}
    public String getLine3() {return salary;}
    public String getLine4() {return "Empolyee: " + name;}
    public String getLine5() {return "salary: ";}

}
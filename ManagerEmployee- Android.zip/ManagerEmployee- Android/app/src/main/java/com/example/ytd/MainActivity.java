package com.example.ytd;

import static com.example.ytd.R.id.recyclerview;

import android.app.DatePickerDialog;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;

import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.util.ArrayList;
import java.util.Calendar;

public class MainActivity extends AppCompatActivity {
    ArrayList<ExampleItem> mExampleList;
    private RecyclerView mRecyclerView;
    private ExampleAdapter mAdapter;
    private RecyclerView.LayoutManager mLayoutManager;
    DatePickerDialog.OnDateSetListener setListener;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Date();
        loadData();
        buildRecyclerView();
        setInsertButton();
        addEmp();
        totalsum();
        calculateAverage();

        // save button
        Button buttonSave = findViewById(R.id.button_save);
        buttonSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {saveData();}});
    }


    private void saveData() {

        SharedPreferences sharedPreferences = getSharedPreferences("shared preferences", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        Gson gson = new Gson();
        String json = gson.toJson(mExampleList);
        editor.putString("task list", json);
        editor.apply();
        }


    private void loadData() {

       SharedPreferences sharedPreferences = getSharedPreferences("shared preferences", MODE_PRIVATE);
        Gson gson = new Gson();
        String json = sharedPreferences.getString("task list", null);
        mExampleList = gson.fromJson(json, new TypeToken<ArrayList<ExampleItem>>() {}.getType());
        if (mExampleList == null){
            mExampleList = new ArrayList<>();
        }
        addEmp();
    }


    private void buildRecyclerView() {
        mRecyclerView = findViewById(recyclerview);
        mRecyclerView.setHasFixedSize(true);
        mLayoutManager = new LinearLayoutManager(this);
        mAdapter = new ExampleAdapter(mExampleList);

        mRecyclerView.setLayoutManager(mLayoutManager);
        mRecyclerView.setAdapter(mAdapter);

        //Delete btn
        mAdapter.setOnItemClickListener(new ExampleAdapter.OnItemClickListener() {
            @Override
            public void onDeleteClick(int position) {
                removeItem(position);
                SharedPreferences sharedPreferences = getSharedPreferences("shared preferences", MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedPreferences.edit();
                Gson gson = new Gson();
                String json = gson.toJson(mExampleList);
                editor.putString("task list", json);
                Toast.makeText(MainActivity.this, "Deleted", Toast.LENGTH_SHORT).show();
                editor.apply();
                addEmp();
                totalsum();
                calculateAverage();}
        });
    }


    //insert btn
    private void setInsertButton() {
        Button buttonInsert = findViewById(R.id.button_insert);
        buttonInsert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText line1 = findViewById(R.id.edittext_line_1);
                TextView line2 = findViewById(R.id.edittext_line_2);
                EditText line3 = findViewById(R.id.edittext_line_3);
                EditText line4 = findViewById(R.id.edittext_line_4);

                if (line4.getText().toString().trim().length()<=0) {
                    Toast.makeText(MainActivity.this, "Name: is empty", Toast.LENGTH_SHORT).show();
                }

                 else if (line3.getText().toString().trim().length()<=0) {
                    Toast.makeText(MainActivity.this, "Salary: is empty", Toast.LENGTH_SHORT).show();}

                else {
                    insertItem(line1.getText().toString(), line2.getText().toString(),line3.getText().toString(),line4.getText().toString());
                    addEmp();
                    totalsum();
                    calculateAverage();}}
        });
    }

    public double calculateAverage(){
    TextView avgTextView = findViewById(R.id.avg_text_view);
    double sum1 = totalsum();
    int size = mExampleList.size();
    int avarage= (int) (sum1 / size);
     avgTextView.setText("Avg salary: " +avarage);

     return avarage;
    }


    // total salary
    public double totalsum(){
        TextView sum_text = findViewById(R.id.summantext);
        int sum= 0;

        for (int i = 0;
             i<mExampleList.size(); i++)

        {sum +=Integer.parseInt(mExampleList.get(i).getLine3());}

        sum_text.setText("Total salary: " +sum);
        return sum;
    }


    // number of employees
    public void addEmp(){
            TextView textView = findViewById(R.id.textview);
            String total = "";

        for (int i = 0;
             i<mExampleList.size(); i++)

        {total = String.valueOf(mExampleList.size());}

        textView.setText("Number of employees: "+total);
    }


    // insert all the lines
    private void insertItem(String line1, String line2, String line3, String line4) {
        mExampleList.add(new ExampleItem(line1 , line2,line3,line4));
        mAdapter.notifyItemInserted(mExampleList.size());}



    public void removeItem(int position) {
        mExampleList.remove(position);
        mAdapter.notifyItemRemoved(position);}



    //Select Date
    public void Date(){

        Calendar calendar = Calendar.getInstance();
        final int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);
        TextView edittext_line_2 = findViewById(R.id.edittext_line_2);

        edittext_line_2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DatePickerDialog datePickerDialog = new DatePickerDialog(
                            MainActivity.this, android.R.style.Theme_Holo_Light_Dialog_MinWidth,setListener
                        ,year,month,day);
                datePickerDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                datePickerDialog.show();}
        });

        setListener= new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int month, int dayOfMonth) {
                month= month+1;
                String date = day+"/"+month;
                String date2= date+"/";
                String date3= date2+year;
                edittext_line_2.setText(date3);}
        };

    }




}
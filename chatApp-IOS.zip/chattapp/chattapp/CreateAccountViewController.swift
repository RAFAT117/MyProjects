//
//  CreateAccountViewController.swift
//  chattapp
//
//  Created by Rafaat.Al-Badri on 2023-04-11.
//

import UIKit
import Firebase

class CreateAccountViewController: UIViewController, UITextFieldDelegate{
    
    @IBOutlet weak var EnterEmailTextField: UITextField!
    @IBOutlet weak var EnterName: UITextField!
    @IBOutlet weak var EnterPasswordTextField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        navigationController?.setNavigationBarHidden(false, animated: true)
    
        EnterName.delegate = self
        EnterEmailTextField.delegate = self
        EnterPasswordTextField.delegate = self
    }
    
    
    @IBAction func SignupClicked(_ sender: UIButton) {
        
        guard let email = EnterEmailTextField.text, !email.isEmpty, let password = EnterPasswordTextField.text, !password.isEmpty, let name = EnterName.text, !name.isEmpty else {
            
            // Show alert with error message for empty fields
            let alert = UIAlertController(title: "Error", message: "Please enter name, email, and password", preferredStyle: .alert)
            let okAction = UIAlertAction(title: "OK", style: .default, handler: nil)
            alert.addAction(okAction)
            self.present(alert, animated: true, completion: nil)
            return
        }
        
        // Check if email is valid
        if !isValidEmail(email: email) {
            // Show alert with error message for invalid email
            let alert = UIAlertController(title: "Error", message: "Please enter a valid email address", preferredStyle: .alert)
            let okAction = UIAlertAction(title: "OK", style: .default, handler: nil)
            alert.addAction(okAction)
            self.present(alert, animated: true, completion: nil)
            return
        }
        
        // Check if password is at least 6 characters long
        if password.count < 6 {
            // Show alert with error message for password length
            let alert = UIAlertController(title: "Error", message: "Password must be at least 6 characters long", preferredStyle: .alert)
            let okAction = UIAlertAction(title: "OK", style: .default, handler: nil)
            alert.addAction(okAction)
            self.present(alert, animated: true, completion: nil)
            return
        }

        Auth.auth().createUser(withEmail: email, password: password) { authResult, error in
            if let e = error {
                print(error)
                // Show alert with error message for general error
                let alert = UIAlertController(title: "Error", message: "Failed to create user. Please try again.", preferredStyle: .alert)
                let okAction = UIAlertAction(title: "OK", style: .default, handler: nil)
                alert.addAction(okAction)
                self.present(alert, animated: true, completion: nil)
                return
            }
            
            guard let user = authResult?.user else { return }
            let fromUserID = user.uid
            let userData = ["name": name, "email": email]
            let usersRef = Database.database().reference().child("Users")
            usersRef.child(fromUserID).setValue(userData)

            // Go to the next screen
            self.performSegue(withIdentifier: "goToNext", sender: self)

        }
    }

    func isValidEmail(email: String) -> Bool {
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}"
        let emailPred = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        return emailPred.evaluate(with: email)
    }

    
        
        func textFieldShouldReturn(_ textField: UITextField) -> Bool {
            if textField == EnterEmailTextField {
                EnterPasswordTextField.becomeFirstResponder()
            }
            else if textField == EnterPasswordTextField {
                textField.resignFirstResponder()
            }
            return true
        }

    }
 


//
//  sakerhetViewController.swift
//  chattapp
//
//  Created by Rafaat.Al-Badri on 2023-04-16.
//

import UIKit

class sakerhetViewController: UIViewController,UIImagePickerControllerDelegate, UINavigationControllerDelegate, UITableViewDelegate, UITableViewDataSource {

            
            let cellTitles = ["Lösenord", "E-post"]
            let cellImages = ["key", "envelope.badge.shield.half.filled"]

            let cellIdentifier = "cell"
            

    @IBOutlet weak var tableView: UITableView!
            
            override func viewDidLoad() {
                super.viewDidLoad()
                
                tableView.delegate = self
                tableView.dataSource = self
                tableView.register(UITableViewCell.self, forCellReuseIdentifier: cellIdentifier)

            }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
               return cellTitles.count
           }
         
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
               
               let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier, for: indexPath)
        
               cell.accessoryType = .disclosureIndicator
        
               cell.textLabel?.text = cellTitles[indexPath.row]
               cell.imageView?.image = UIImage(systemName: cellImages[indexPath.row])

               return cell
           }
           
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
               tableView.deselectRow(at: indexPath, animated: true)
               switch indexPath.row {
               case 0:
                   
                   performSegue(withIdentifier: "losenord", sender: nil)
                   break
               case 1:
                   performSegue(withIdentifier: "email", sender: nil)
                   break
                   
               default:
                   break
               }
           }
     
        }
    
    


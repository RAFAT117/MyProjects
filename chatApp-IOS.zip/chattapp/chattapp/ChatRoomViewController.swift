//
//  ChatViewController.swift
//  chattapp
//
//  Created by Rafaat.Al-Badri on 2023-04-12.
//



import UIKit
import Firebase
import StoreKit
import AVFoundation

class Message {
    var from: String
    var to: String
    var text: String
    var timestamp: TimeInterval
    
    init(from: String, to: String, text: String, timestamp: TimeInterval) {
        self.from = from
        self.to = to
        self.text = text
        self.timestamp = timestamp
    }
}


class ChatRoomViewController: UIViewController, UITableViewDelegate, UITableViewDataSource, UITextFieldDelegate {
    
    
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var messageTextField: UITextField!
    
    var messages: [Message] = []
      var recipientID: String?
      var recipientName: String?
      var MesssagenSnapshot: [DataSnapshot] = []
      var chatID: String?
      var otherUserID: String?

    override func viewDidLoad() {
        super.viewDidLoad()
        
        updateOverlayOpacity()
        tableView.delegate = self
        tableView.dataSource = self
        messageTextField.delegate = self
        
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "MessageCell")
        
        messageTextField.layer.cornerRadius = 10
        messageTextField.layer.borderWidth = 1
        messageTextField.layer.borderColor = UIColor.gray.cgColor
      
        loadMessages()
        self.tableView.reloadData()

    }


    override func traitCollectionDidChange(_ previousTraitCollection: UITraitCollection?) {
        super.traitCollectionDidChange(previousTraitCollection)
        updateOverlayOpacity()
    }
    
    // Check if the current user interface style is dark mode else
    private func updateOverlayOpacity() {
        if self.traitCollection.userInterfaceStyle == .dark {
            view.layer.sublayers?.first(where: { $0 is AVPlayerLayer })?.removeFromSuperlayer()
           
            // Set up the video player only in dark mode
            let videoURL = Bundle.main.url(forResource: "DarkBg", withExtension: "mp4")
            let player = AVPlayer(url: videoURL!)
            player.rate = 0.5
            let playerLayer = AVPlayerLayer(player: player)
            playerLayer.frame = self.view.frame
            playerLayer.videoGravity = .resizeAspectFill
            self.view.layer.insertSublayer(playerLayer, at: 0)
            player.play()

            NotificationCenter.default.addObserver(forName: .AVPlayerItemDidPlayToEndTime, object: player.currentItem, queue: .main) { _ in
                player.seek(to: CMTime.zero)
                player.play()
            }

        } else {
            view.layer.sublayers?.first(where: { $0 is AVPlayerLayer })?.removeFromSuperlayer()
            

            // Set up the video player only in light mode
            let videoURL = Bundle.main.url(forResource: "WhiteBg", withExtension: "mp4")
            let player = AVPlayer(url: videoURL!)
            player.rate = 0.5
            let playerLayer = AVPlayerLayer(player: player)
            playerLayer.frame = self.view.frame
            playerLayer.videoGravity = .resizeAspectFill
            self.view.layer.insertSublayer(playerLayer, at: 0)
            player.play()

            NotificationCenter.default.addObserver(forName: .AVPlayerItemDidPlayToEndTime, object: player.currentItem, queue: .main) { _ in
                player.seek(to: CMTime.zero)
                player.play()
            }
        }
    }
    
    
    @IBAction func sendButtonTapped(_ sender: Any)  {
        
        guard let currentUserID = Auth.auth().currentUser?.uid else {
            print("current user is nil")
            return
        }
        
        guard let recipientID = recipientID else {
               print("recipient ID is nil")
               return
           }

           
           guard let text = messageTextField.text, !text.isEmpty else {
               print("Text field is empty!")
               return
           }

        
        let chatRef = Database.database().reference().child("Chats")
        let messageRef = Database.database().reference().child("messages").childByAutoId()
        let messageData: [String: Any] = [
            "from": currentUserID,
            "to": recipientID,
            "text": text,
            "timestamp": ServerValue.timestamp()
        ]
        messageRef.setValue(messageData)

        
        // Create a Message object for the new message and append it to the messages array
        let message = Message(from: currentUserID, to: recipientID, text: text, timestamp: Date().timeIntervalSince1970)
        
        self.tableView.reloadData()
        
        let indexPath = IndexPath(row: self.messages.count - 1, section: 0)
        
        
        // Clear the text field
        messageTextField.text = ""
    }
    
    
    func loadMessages() {
        guard let currentUserID = Auth.auth().currentUser?.uid else {
            print("current user is nil")
            return
        }

        let messagesRef = Database.database().reference().child("messages")
        messagesRef.queryOrdered(byChild: "timestamp").observe(.childAdded) { snapshot in
            guard let messageDict = snapshot.value as? [String: Any],
                let fromUserID = messageDict["from"] as? String,
                let toUserID = messageDict["to"] as? String,
                let text = messageDict["text"] as? String,
                let timestamp = messageDict["timestamp"] as? TimeInterval
                else {
                    return
            }

            // Only load messages that are relevant to the currently logged in user
            if (fromUserID == currentUserID && toUserID == self.recipientID) || (fromUserID == self.recipientID && toUserID == currentUserID) {
                
                let message = Message(from: fromUserID, to: toUserID, text: text, timestamp: timestamp)
                self.messages.append(message)
                self.tableView.reloadData()
                let indexPath = IndexPath(row: self.messages.count - 1, section: 0)
                self.tableView.scrollToRow(at: indexPath, at: .bottom, animated: true)
            }
        }
    }
    
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return messages.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "MessageCell", for: indexPath)
        
        let message = messages[indexPath.row]
        cell.textLabel?.text = message.text
        cell.backgroundColor  = .clear
        
        //User textlabel
        if message.from == Auth.auth().currentUser?.uid {
       
            cell.textLabel?.textAlignment = .right
            cell.textLabel?.textColor = UIColor(red: 0.0, green: 0.5, blue: 0.0, alpha: 1.0)
        } else {
            
            //Friend textlabel
            cell.textLabel?.textAlignment = .left
           
        }
        
        cell.textLabel?.font = UIFont.systemFont(ofSize: 21)
        
        return cell
    }
    
    
}

//
//  profilViewController.swift
//  chattapp
//
//  Created by Rafaat.Al-Badri on 2023-04-11.
//


import UIKit
import StoreKit
import Firebase

class profilViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet weak var tableView: UITableView!
    
    let cellTitles = ["Säkerhet","Mörkt läge","Logga ut","Radera konto"]
    let cellImages = ["lock", "moon.stars", "person.crop.circle.badge.xmark", "trash"]
    
    let cellIdentifier = "cell"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        navigationController?.setNavigationBarHidden(false, animated: true)
        
        tableView.delegate = self
        tableView.dataSource = self
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: cellIdentifier)
        
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return cellTitles.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier, for: indexPath)
        
        cell.accessoryType = .disclosureIndicator
        
        cell.imageView?.image = UIImage(systemName: cellImages[indexPath.row])
        
        cell.textLabel?.text = cellTitles [indexPath.row]
        
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        switch indexPath.row {
        case 0:
            performSegue(withIdentifier: "sakerhet", sender: nil)
            break
            
        case 1:
            performSegue(withIdentifier: "mode", sender: nil)

            break
    
            
        case 2:
            let alertController = UIAlertController(title: nil, message: "Är du säker på att du vill logga ut?", preferredStyle: .alert)
            let confirmAction = UIAlertAction(title: "Logga ut", style: .destructive) { (_) in
                do {
                    try Auth.auth().signOut() // sign out the current user
                    self.performSegue(withIdentifier: "logout", sender: nil)
                } catch let error {
                    print("Error signing out: \(error.localizedDescription)")
                }
            }
            let cancelAction = UIAlertAction(title: "Avbryt", style: .cancel)
            alertController.addAction(confirmAction)
            alertController.addAction(cancelAction)
            present(alertController, animated: true, completion: nil)
            
            
            
        case 3:
            let alertController = UIAlertController(title: "Radera konto", message: "Är du säker på att du vill ta bort ditt konto?", preferredStyle: .alert)
            
            let cancelAction = UIAlertAction(title: "Avbryt", style: .cancel, handler: nil)
            alertController.addAction(cancelAction)
            
            let deleteAction = UIAlertAction(title: "Radera", style: .destructive) { _ in
                let user = Auth.auth().currentUser
                user?.delete { [self] error in
                    if let error = error {
                        print("Error deleting user: \(error.localizedDescription)")
                    } else {
                        
                        let alertController = UIAlertController(title: "Kontot raderat", message: "Ditt konto har raderats.", preferredStyle: .alert)
                        let okAction = UIAlertAction(title: "OK", style: .default) { (action) in
                            
                            
                            self.performSegue(withIdentifier: "Raderakonto", sender: nil)
                            
                        }
                        alertController.addAction(okAction)
                        self.present(alertController, animated: true, completion: nil)
                        
                    }
                }
            }
            
            alertController.addAction(deleteAction)
            present(alertController, animated: true, completion: nil)
            
            break
            
        default:
            break
            
        }
    }
}
    



//
//  ViewController.swift
//  chattapp
//
//  Created by Rafaat.Al-Badri on 2023-04-11.
//

import UIKit
import AVFoundation
import Firebase
import FirebaseFirestore
import CoreData


class ViewController: UIViewController, UITextFieldDelegate {
    
    @IBOutlet weak var EmailTextField: UITextField!
    
    @IBOutlet weak var PasswordTextField: UITextField!
    
    // Reference to the Core Data context
       let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
       
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // ta bort back
        navigationController?.setNavigationBarHidden(true, animated: true)
        
        do {
                let fetchRequest: NSFetchRequest<DarkModePreference> = DarkModePreference.fetchRequest()
                let darkModePreferences = try context.fetch(fetchRequest)
                if let darkModePreference = darkModePreferences.first {
                    
                    // Access isDarkModeEnabled in coreModel
                    let isDarkModeEnabled = darkModePreference.isDarkModeEnabled
                    
                    // Update the user interface based on the value of isDarkModeEnabled
                    let window = UIApplication.shared.windows.first
                    window?.overrideUserInterfaceStyle = isDarkModeEnabled ? .dark : .light
                }
            } catch {
                print("Failed to fetch DarkModePreference: \(error.localizedDescription)")
            }

        
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(handleTap))
        view.addGestureRecognizer(tapGesture)
        
        
        let videoURL = Bundle.main.url(forResource: "startBg", withExtension: "mp4")
        
        // Initialize the AVPlayer
        let player = AVPlayer(url: videoURL!)
        
       
        
        // Create the AVPlayerLayer and set its frame to the view's bounds
        let playerLayer = AVPlayerLayer(player: player)
        playerLayer.frame = self.view.frame
        
        // Set the gravity of the layer to resize aspect fill
        playerLayer.videoGravity = .resizeAspectFill
        
        // Add the player layer as a sublayer of the view's layer
        self.view.layer.insertSublayer(playerLayer, at: 0)
        
        // Play the video
        player.play()
        
        // Loop the video
        NotificationCenter.default.addObserver(forName: .AVPlayerItemDidPlayToEndTime, object: player.currentItem, queue: .main) { _ in
            player.seek(to: CMTime.zero)
            player.play()
        }
    }
    
   
    @objc func handleTap() {
        EmailTextField.resignFirstResponder()
        PasswordTextField.resignFirstResponder()
        
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        if textField == EmailTextField {
            PasswordTextField.becomeFirstResponder()
        }
        else if textField == PasswordTextField {
            textField.resignFirstResponder()
        }
        return true
        
    }
    
    
    
    @IBAction func SignInClicked(_ sender: UIButton) {
            guard let email = EmailTextField.text else { return }
            guard let password = PasswordTextField.text else { return }
            
            // Query the Firebase database for a user with the given email
            Auth.auth().fetchSignInMethods(forEmail: email) { signInMethods, error in
                if let error = error {
                    print("Error fetching sign-in methods: \(error.localizedDescription)")
                    return
                }
                
                // If there are no sign-in methods for the given email, it's not registered
            guard let signInMethods = signInMethods, !signInMethods.isEmpty else {
                
                    // Show alert with error message
                    let alert = UIAlertController(title: "Fel", message: "E-post inte registrerad", preferredStyle: .alert)
                    let okAction = UIAlertAction(title: "OK", style: .default, handler: nil)
                    alert.addAction(okAction)
                    self.present(alert, animated: true, completion: nil)
                    return
                }
                
                // Attempt to sign in with the given email and password
           Auth.auth().signIn(withEmail: email, password: password) { result, error in
               if let error = error {
                   
                       // Show alert with error message
                       let alert = UIAlertController(title: "Fel", message: "Felaktig e-postadress eller lösenord", preferredStyle: .alert)
                       let okAction = UIAlertAction(title: "OK", style: .default, handler: nil)
                       alert.addAction(okAction)
                       self.present(alert, animated: true, completion: nil)
                   } else {
                       
                       // Go to the home screen
                       self.performSegue(withIdentifier: "goToNext", sender: self)
                   }
                }
            }
        }

   
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        if Auth.auth().currentUser != nil {
            // User is signed in, so go to the home screen directly
                self.performSegue(withIdentifier: "goToNext" ,sender: self)
            }
        }
    }



//
//  bytEpost.swift
//  chattapp
//
//  Created by Rafaat.Al-Badri on 2023-04-16.
//


import UIKit
import Firebase
import FirebaseAuth
import FirebaseDatabase


class bytEpost: UIViewController {

    
    @IBOutlet weak var saveButton: UIBarButtonItem!
    
    @IBOutlet weak var emailTextField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let label = UILabel(frame: CGRect(x: 20, y: 0, width: 90, height: 30))
        label.text = "E-post:"
        label.textAlignment = .left

        let paddingView = UIView(frame: CGRect(x: 0, y: 0, width: 100, height: 30))
        paddingView.addSubview(label)
        
        emailTextField.leftView = paddingView
        emailTextField.leftViewMode = .always

        emailTextField.addTarget(self, action: #selector(textFieldDidChange), for: .editingChanged)
        
        // set the email text field to the user's current email address
        if let currentUser = Auth.auth().currentUser {
            emailTextField.text = currentUser.email
        }
    }
    
    @objc func textFieldDidChange() {
        // Enable save button only if all text fields have input
        if let email = emailTextField.text, isValidEmail(email: email) {
            saveButton.isEnabled = true
        } else {
            saveButton.isEnabled = false
        }
        
    }


    @IBAction func updateEmailTapped(_ sender: Any) {
        guard let newEmail = emailTextField.text, !newEmail.isEmpty else {
            return
        }

        // Update the user's email address in Firebase Auth
        Auth.auth().currentUser?.updateEmail(to: newEmail) { (error) in
            if let error = error as NSError? {
                print("Error updating email: \(error.localizedDescription)")
                
                // Check if the error is due to recent authentication requirement
                if error.code == AuthErrorCode.requiresRecentLogin.rawValue {
                    // Display an alert to inform the user to log out and log in again
                    let alert = UIAlertController(title: "Fel", message: "Den här åtgärden är känslig och kräver nyligen autentisering. Logga ut och logga in igen för att uppdatera din e-postadress.", preferredStyle: .alert)
                    let action = UIAlertAction(title: "OK", style: .default)
                    alert.addAction(action)
                    self.present(alert, animated: true)
                }
            } else {
                print("E-posten har uppdaterats")

                // Get a reference to the current user's database node
                guard let currentUserID = Auth.auth().currentUser?.uid else {
                    return
                }
                let ref = Database.database().reference().child("Users").child(currentUserID)

                // Update the email address value in the user's node
                ref.child("email").setValue(newEmail)

                self.displayAlert(message: "E-post har ändrats")
            }
        }
    }


    
    func isValidEmail(email: String) -> Bool {
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}"
        let emailPred = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        return emailPred.evaluate(with: email)
    }
    
    func displayAlert(message: String) {
        let alert = UIAlertController(title: nil, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        present(alert, animated: true, completion: nil)
    }
}


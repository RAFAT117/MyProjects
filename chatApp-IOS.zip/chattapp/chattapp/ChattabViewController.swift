//
//  ChattabViewController.swift
//  chattapp
//
//  Created by Rafaat.Al-Badri on 2023-04-13.
//

import UIKit
import Firebase
import AVFoundation

class ChattabViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    
    @IBOutlet weak var tableView: UITableView!
    
    var friends = [User]()
    var allFriends: [DataSnapshot] = []

    override func viewDidLoad() {
        super.viewDidLoad()
      
        tableView.delegate = self
        tableView.dataSource = self
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "FriendsCell")
        // Set the background color of the table view's superview to clear
        
       
        updateOverlayOpacity()
        
        // Load the user's friend list from the database
        loadFriends()
    }

    override func traitCollectionDidChange(_ previousTraitCollection: UITraitCollection?) {
        super.traitCollectionDidChange(previousTraitCollection)
        updateOverlayOpacity() // Call a method to update the overlay opacity when the trait collection changes
    }
    // Check if the current user interface style is dark mode else
    private func updateOverlayOpacity() {
        if self.traitCollection.userInterfaceStyle == .dark {
            view.layer.sublayers?.first(where: { $0 is AVPlayerLayer })?.removeFromSuperlayer()
           
            // Set up the video player only in dark mode
            let videoURL = Bundle.main.url(forResource: "DarkBg", withExtension: "mp4")
            let player = AVPlayer(url: videoURL!)
            player.rate = 0.5
            let playerLayer = AVPlayerLayer(player: player)
            playerLayer.frame = self.view.frame
            playerLayer.videoGravity = .resizeAspectFill
            self.view.layer.insertSublayer(playerLayer, at: 0)
            player.play()

            NotificationCenter.default.addObserver(forName: .AVPlayerItemDidPlayToEndTime, object: player.currentItem, queue: .main) { _ in
                player.seek(to: CMTime.zero)
                player.play()
            }

        } else {
            view.layer.sublayers?.first(where: { $0 is AVPlayerLayer })?.removeFromSuperlayer()
            

            // Set up the video player only in light mode
            let videoURL = Bundle.main.url(forResource: "WhiteBg", withExtension: "mp4")
            let player = AVPlayer(url: videoURL!)
            player.rate = 0.5
            let playerLayer = AVPlayerLayer(player: player)
            playerLayer.frame = self.view.frame
            playerLayer.videoGravity = .resizeAspectFill
            self.view.layer.insertSublayer(playerLayer, at: 0)
            player.play()

            NotificationCenter.default.addObserver(forName: .AVPlayerItemDidPlayToEndTime, object: player.currentItem, queue: .main) { _ in
                player.seek(to: CMTime.zero)
                player.play()
            }
        }
    }



    func loadFriends() {
        guard let currentUserID = Auth.auth().currentUser?.uid else { return }
        
        let friendsRef = Database.database().reference().child("Friends").child(currentUserID).child("List")
        
        friendsRef.observe(.childAdded) { snapshot in
            let friendID = snapshot.key
            
            // Load the friend's information from the Users node in the database
            let usersRef = Database.database().reference().child("Users").child(friendID)
            usersRef.observeSingleEvent(of: .value) { snapshot in
                self.allFriends.append(snapshot)
                self.tableView.reloadData()
            }
        }
    }
    
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return allFriends.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "FriendsCell", for: indexPath)
        cell.accessoryType = .disclosureIndicator
        
        cell.textLabel?.font = UIFont.systemFont(ofSize: 23)
        cell.backgroundColor = .clear

        let friendID = allFriends[indexPath.row].key
        
        // Load the friend's information from the Users node in the database
        let usersRef = Database.database().reference().child("Users").child(friendID)
        usersRef.observeSingleEvent(of: .value) { snapshot in
            if let user = snapshot.value as? [String: Any] {
                let name = user["name"] as? String ?? "Unknown"
             
                DispatchQueue.main.async {
                    cell.textLabel?.text = "\(name)" //display name
                }
            }
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let friendRequest = allFriends[indexPath.row]
        let friendID = friendRequest.key
        guard let currentUserID = Auth.auth().currentUser?.uid else { return }
        
        // Generate a chat ID
        let chatID = "\(currentUserID)-\(friendID)"
        
        // Create a new chat room in the database
        let chatsRef = Database.database().reference().child("Chats")
        let chatData = ["Users": [currentUserID, friendID]]
        chatsRef.child(chatID).setValue(chatData)
        
        // Navigate to the chat room view controller
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let chatVC = storyboard.instantiateViewController(withIdentifier: "ChatRoomViewController") as! ChatRoomViewController
        chatVC.chatID = chatID
        chatVC.recipientID = friendID
        navigationController?.pushViewController(chatVC, animated: true)
     
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        if let indexPath = tableView.indexPathForSelectedRow {
            tableView.deselectRow(at: indexPath, animated: true)
        }
    }

}

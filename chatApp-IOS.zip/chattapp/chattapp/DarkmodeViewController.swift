//
//  DarkmodeViewController.swift
//  chattapp
//
//  Created by Rafaat.Al-Badri on 2023-04-16.
//
import UIKit
import CoreData

class DarkmodeViewController: UIViewController {

    @IBOutlet weak var darkModeSwitch: UISwitch!

    // Reference to the Core Data context
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    
    override func viewDidLoad() {
        super.viewDidLoad()
      
        
        do {
               let fetchRequest: NSFetchRequest<DarkModePreference> = DarkModePreference.fetchRequest()
               let darkModePreferences = try context.fetch(fetchRequest)
               if let darkModePreference = darkModePreferences.first {
                   
                   // Access the isDarkModeEnabled in coreModel
                   let isDarkModeEnabled = darkModePreference.isDarkModeEnabled
                   
                   // Update the user interface based on the value of isDarkModeEnabled
                   let window = UIApplication.shared.windows.first
                   window?.overrideUserInterfaceStyle = isDarkModeEnabled ? .dark : .light
                   
                   // Update UISwitch based on the value of isDarkModeEnabled
                   darkModeSwitch.isOn = isDarkModeEnabled
               }
           } catch {
               print("Failed to fetch DarkModePreference: \(error.localizedDescription)")
           }
    }
        

    @IBAction func switchValueChanged(_ sender: UISwitch) {
        // Fetch the DarkModePreference from Core Data
        do {
            let fetchRequest: NSFetchRequest<DarkModePreference> = DarkModePreference.fetchRequest()
            let darkModePreferences = try context.fetch(fetchRequest)
            if let darkModePreference = darkModePreferences.first {
                // Update the existing entity
                darkModePreference.isDarkModeEnabled = sender.isOn
            }
            try context.save() // Save changes to Core Data
        } catch {
            print("Failed to save DarkModePreference: \(error.localizedDescription)")
        }
        
        // Update the user interface based on the switch value
        let window = UIApplication.shared.windows.first
        window?.overrideUserInterfaceStyle = sender.isOn ? .dark : .light
    }
}

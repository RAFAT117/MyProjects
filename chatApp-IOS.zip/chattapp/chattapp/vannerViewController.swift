//
//  vannerViewController.swift
//  chattapp
//
//  Created by Rafaat.Al-Badri on 2023-04-11.

import UIKit
import Firebase

class vannerViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    @IBOutlet weak var addBtn: UIButton!
    @IBOutlet weak var emailField: UITextField!
    
    @IBOutlet weak var bgadd: UITextView!
    @IBOutlet weak var tableView: UITableView!
    
    // array to store friend requests
    var friendRequests: [DataSnapshot] = []
    
    // store user objects
    var users = [User]()
    
    // store the current user object
    var currentUser: User?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tableView.delegate = self
        tableView.dataSource = self
        
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "FriendRequestCell")
        
        // Configure appearance
        addBtn.layer.cornerRadius = 10
        addBtn.layer.borderWidth = 1
        addBtn.layer.borderColor = UIColor.gray.cgColor
        
        emailField.layer.cornerRadius = 10
        emailField.layer.borderWidth = 1
        emailField.layer.borderColor = UIColor.gray.cgColor
        
        tableView.layer.cornerRadius = 10
        tableView.layer.borderWidth = 1
        tableView.layer.borderColor = UIColor.gray.cgColor
        
        bgadd.layer.cornerRadius = 10
        bgadd.layer.borderWidth = 1
        bgadd.layer.borderColor = UIColor.gray.cgColor
        
        // Load friend requests for the current user
        loadFriendRequests()
        
    
    }
    
  

    func loadFriendRequests() {
        guard let currentUserID = Auth.auth().currentUser?.uid else { return }
        
        let friendRequestsRef = Database.database().reference().child("Friends").child(currentUserID).child("Requests")
        
        friendRequestsRef.observe(.childAdded) { snapshot in
            self.friendRequests.append(snapshot)
            self.tableView.reloadData()
        }
    }
    
    func acceptFriendRequest(at index: Int) {
        // Get the friend request from the friendRequests array
        let friendRequest = friendRequests[index]
        guard let currentUserID = Auth.auth().currentUser?.uid else { return }
        
        let alertController = UIAlertController(title: "Lägg till vän", message: "Är du säker på att du vill lägga till den här användaren som vän?", preferredStyle: .alert)
        
        let addAction = UIAlertAction(title: "Lägg till", style: .default) { _ in
            let friendsRef = Database.database().reference().child("Friends")
            let friendID = friendRequest.childSnapshot(forPath: "from").value as! String
            let currentUserFriendRef = friendsRef.child(currentUserID).child("List").child(friendID)
            currentUserFriendRef.setValue(true)
            
            let friendFriendRef = friendsRef.child(friendID).child("List").child(currentUserID)
            friendFriendRef.setValue(true)
            
            let friendRequestsRef = friendsRef.child(currentUserID).child("Requests")
            friendRequestsRef.child(friendRequest.key).removeValue()
            
            self.friendRequests.remove(at: index)
            self.tableView.reloadData()
        }
        
        let cancelAction = UIAlertAction(title: "Ta bort", style: .cancel) { _ in
          
            let friendRequestsRef = Database.database().reference().child("Friends").child(currentUserID).child("Requests")
       
            friendRequestsRef.child(friendRequest.key).removeValue()
            self.friendRequests.remove(at: index)
            self.tableView.reloadData()
        }
        
        alertController.addAction(addAction)
        alertController.addAction(cancelAction)
        present(alertController, animated: true, completion: nil)
        
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return friendRequests.count // Returns the number of friend requests
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "FriendRequestCell", for: indexPath)
        let friendRequest = friendRequests[indexPath.row]
       
        if let fromUserID = friendRequest.childSnapshot(forPath: "from").value as? String {
            let usersRef = Database.database().reference().child("Users")
            let query = usersRef.queryOrderedByKey().queryEqual(toValue: fromUserID)
            query.observeSingleEvent(of: .value) { snapshot in
                if let user = snapshot.children.allObjects.first as? DataSnapshot {
                    let name = user.childSnapshot(forPath: "name").value as! String
                    let email = user.childSnapshot(forPath: "email").value as! String
                    DispatchQueue.main.async {
                        cell.textLabel?.text = "\(name) (\(email))"
                    }
                }
            }
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        acceptFriendRequest(at: indexPath.row) // Calls the acceptFriendRequest() function
    }
    
    @IBAction func addFriendButtonTapped(_ sender: UIButton) {
        guard let email = emailField.text else { return }
        
        if !isValidEmail(email) {
            
            // Displays an alert with an error message if the email is invalid
            let alert = UIAlertController(title: "Ogiltig e-postadress", message: "Vänligen ange en giltig e-postadress", preferredStyle: .alert)
            let action = UIAlertAction(title: "OK", style: .default)
            alert.addAction(action)
            present(alert, animated: true)
            return
        }
        
        // Retrieves the current user's ID from Firebase Authentication
        guard let currentUserID = Auth.auth().currentUser?.uid else { return }
        
        // Creates a reference to the "Users" node in Firebase Realtime Database
        let usersRef = Database.database().reference().child("Users")
        
        // Queries the "Users" node to check if there is a user with the given email
        let query = usersRef.queryOrdered(byChild: "email").queryEqual(toValue: email)
        query.observeSingleEvent(of: .value) { snapshot in
            guard let user = snapshot.children.allObjects.first as? DataSnapshot else {
                
                // Displays an alert indicating that the user was not found
                let alert = UIAlertController(title: "Användaren hittades inte", message: "Det gick inte att hitta en användare med den angivna e-postadressen.", preferredStyle: .alert)
                let action = UIAlertAction(title: "OK", style: .default)
                alert.addAction(action)
                self.present(alert, animated: true)
                return
            }
            
            // Creates a friend request by adding the current user's ID to the "Requests" child node
            let friendRequestsRef = Database.database().reference().child("Friends").child(user.key).child("Requests")
            let request = ["from": currentUserID]
            friendRequestsRef.childByAutoId().setValue(request)
            
            // Displays an alert indicating that the friend request has been sent
            let alert = UIAlertController(title: "Vänförfrågan skickad", message: "Din vänförfrågan har skickats till \(email).", preferredStyle: .alert)
            let action = UIAlertAction(title: "OK", style: .default)
            alert.addAction(action)
            DispatchQueue.main.async {
                self.present(alert, animated: true)
            }
        }
    }
    
    // Function to validate if an email is in a valid format
    func isValidEmail(_ email: String) -> Bool {
        let emailRegex = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
        let emailPredicate = NSPredicate(format:"SELF MATCHES %@", emailRegex)
        return emailPredicate.evaluate(with: email)
    }
}

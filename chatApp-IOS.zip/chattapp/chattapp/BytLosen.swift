//
//  BytLosen.swift
//  chattapp
//
//  Created by Rafaat.Al-Badri on 2023-04-16.
//


import UIKit
import FirebaseAuth
import Firebase

class BytLosen: UIViewController {

    @IBOutlet weak var currentPasswordTextField: UITextField!
    
    @IBOutlet weak var newPasswordTextField: UITextField!
    
    @IBOutlet weak var saveButton: UIBarButtonItem!
    
    @IBOutlet weak var confirmPasswordTextField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        saveButton.isEnabled = false
               
               currentPasswordTextField.addTarget(self, action: #selector(textFieldDidChange), for: .editingChanged)
               newPasswordTextField.addTarget(self, action: #selector(textFieldDidChange), for: .editingChanged)
               confirmPasswordTextField.addTarget(self, action: #selector(textFieldDidChange), for: .editingChanged)
           }
    

    

@objc func textFieldDidChange() {
       // Enable save button only if all text fields have input
       saveButton.isEnabled = !(currentPasswordTextField.text?.isEmpty ?? true) && !(newPasswordTextField.text?.isEmpty ?? true) && !(confirmPasswordTextField.text?.isEmpty ?? true)
   }
    
    
    @IBAction func saveButtonTapped(_ sender: Any) {
        guard let currentPassword = currentPasswordTextField.text,
                let newPassword = newPasswordTextField.text,
                let confirmPassword = confirmPasswordTextField.text
        else {
            displayAlert(message: "Alla fält är obligatoriska")
            return
        }
        
               guard newPassword == confirmPassword else {
                   displayAlert(message: "Lösenorden matchar inte")
                   return
               }
               
               // Re-authenticate the user 
        guard let currentUser = Auth.auth().currentUser,
              let currentEmail = currentUser.email else {
            displayAlert(message: "Den här åtgärden är känslig och kräver nyligen autentisering. Logga ut och logga in igen för att uppdatera ditt lösenord.")
            return
        }

        let credential = EmailAuthProvider.credential(withEmail: currentEmail, password: currentPassword)


               currentUser.reauthenticate(with: credential) { [weak self] (result, error) in
                   guard let self = self else { return }
                   if error != nil {
                       self.displayAlert(message: "Lösenordet är ogiltigt")
                   } else {
                       
                       // Change the user's password
                       Auth.auth().currentUser?.updatePassword(to: newPassword) { (error) in
                           if error != nil {
                               self.displayAlert(message: "Lösenordet måste vara 6 tecken långt eller mer")
                           } else {
                               self.displayAlert(message: "Lösenordet har ändrats")
                               self.navigationController?.popViewController(animated: true)

                           }
                       }
                   }
               }
           }
           
           func displayAlert(message: String) {
               let alert = UIAlertController(title: nil, message: message, preferredStyle: .alert)
               alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
               present(alert, animated: true, completion: nil)
           }
       }

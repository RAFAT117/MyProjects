package com.example.bmikalk;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import java.text.DecimalFormat;

import javax.xml.transform.Result;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        myButtonListenerMethod();
    }


    public void myButtonListenerMethod() {
        Button button = findViewById(R.id.button);
        TextView Result = findViewById(R.id.Result);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                button.setBackgroundColor(getColor(R.color.Red));
                Result.setBackgroundColor(getColor(R.color.teal_700));


                final EditText heighText = findViewById(R.id.Height);
                String heighstr = heighText.getText().toString();
                double height = Double.parseDouble(heighstr);
                double heightM =height/100;

                final EditText weighText = findViewById(R.id.Weight);
                String weighstr = weighText.getText().toString();
                double weight = Double.parseDouble(weighstr);
                double BMI = (weight) / (heightM * heightM);

                DecimalFormat df= new DecimalFormat("#.#");
                double bmi_Tr= Double.parseDouble((df.format(BMI)));
                final TextView BMIResult= findViewById(R.id.Result);
                BMIResult.setText(Double.toString(bmi_Tr));





            }
        });


    }
}

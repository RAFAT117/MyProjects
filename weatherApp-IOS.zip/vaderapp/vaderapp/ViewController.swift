//
//  ViewController.swift
//  vaderapp
//
//  Created by Rafaat.Al-Badri on 2023-04-17.
//

import UIKit
import CoreLocation

class ViewController: UIViewController, CLLocationManagerDelegate {
    
    @IBOutlet weak var temperatureLabel: UILabel!
    @IBOutlet weak var humidityLabel: UILabel!
    @IBOutlet weak var weatherDescriptionLabel: UILabel!
    
    var locationManager = CLLocationManager()
    var apiKey = "786c2bb79dc6b566bd6aaf7a9e0334f0"
    var units = "metric"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        locationManager.delegate = self
        
        // tillåtelse att använda platstjänster
        locationManager.requestWhenInUseAuthorization()
        
        // uppdatera användarens plats.
        locationManager.startUpdatingLocation()
    }
    
    // anropas när platshanteraren uppdaterar användarens plats.
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        if let location = locations.last {
            let latitude = location.coordinate.latitude
            let longitude = location.coordinate.longitude
            
            let url = "https://api.openweathermap.org/data/2.5/weather?lat=\(latitude)&lon=\(longitude)&units=\(units)&appid=\(apiKey)"
            
            // hämta väderdata från OpenWeatherMap API.
            URLSession.shared.dataTask(with: URL(string: url)!) { data, response, error in
                // If there was an error, print an error message and return.
                guard let data = data, error == nil else {
                    print("Error: \(error!)")
                    return
                }
                
                do {
                    let weatherData = try JSONDecoder().decode(WeatherData.self, from: data)
                    
                    DispatchQueue.main.async {
                        self.temperatureLabel.text = "\(Int(weatherData.main.temp))°"
                        self.humidityLabel.text = "\(weatherData.main.humidity)%"
                        self.weatherDescriptionLabel.text = weatherData.weather.first?.description.capitalized
                    }
                } catch let error {
                    print("Error decoding weather data: \(error)")
                }
            }.resume()
        }
    }
    
}

// Tre strukturer för att hålla väderdata.
struct WeatherData: Codable {
    let main: Main
    let weather: [Weather]
}

struct Main: Codable {
    let temp: Double
    let humidity: Int
}

struct Weather: Codable {
    let description: String
}

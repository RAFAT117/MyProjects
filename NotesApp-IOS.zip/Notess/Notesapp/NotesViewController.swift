//
//  NotesViewController.swift
//  Note.app
//
//  Created by Rafaat.Al-Badri on 2023-03-16.
//

import UIKit

struct Note: Codable {
    var title: String
    var text: String
    var lastUpdated: Date
}


class NotesViewController: UIViewController, UITableViewDelegate, UITableViewDataSource, NewNoteViewControllerDelegate {
    
    @IBOutlet weak var SwtichBtn: UISwitch!
    @IBOutlet weak var addBtn: UIBarButtonItem!
    @IBOutlet weak var tableview: UITableView!
    
    //Array for all the notes
    var notes: [Note] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // set the user interface style to dark mode if it was enabled last time
        if let window = UIApplication.shared.windows.first {
            let DarkModeEnabled = UserDefaults.standard.bool(forKey: "DarkMode")
            window.overrideUserInterfaceStyle = DarkModeEnabled ? .dark : .light
        }

        tableview.delegate = self
        tableview.dataSource = self
        
        loadNotes()
        
        // set the switch to reflect the users saved preference for Dark mode
        let userDefualts = UserDefaults.standard
        let DarkMode = userDefualts.bool(forKey: "DarkMode")
        SwtichBtn.isOn = DarkMode
        
       
            
    }
    
    //if switch is on/off set the mode and save
    @IBAction func switchbtn(_ sender: UISwitch) {
        if sender.isOn {
            UIApplication.shared.keyWindow?.overrideUserInterfaceStyle = .dark
            self.tabBarController?.tabBar.overrideUserInterfaceStyle = .dark
            
            UserDefaults.standard.set(true, forKey: "DarkMode")
        } else {
            UIApplication.shared.keyWindow?.overrideUserInterfaceStyle = .light
            self.tabBarController?.tabBar.overrideUserInterfaceStyle = .light
            UserDefaults.standard.set(false, forKey: "DarkMode")
            }
        }
    
    //saves the users preference for dark mode to userdefualts
    func saveMode (isOn: Bool) {
        let userDefualts = UserDefaults.standard
        userDefualts.set(isOn, forKey: "DarkMode")
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
       return notes.count
    }
    
    
    // fills tableview cell  with a notes title and time
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "noteCell", for: indexPath)
        
        let note = notes[indexPath.row]
        cell.textLabel?.text = note.title
        
        let Time = DateFormatter()
        Time.dateStyle = .short
        Time.timeStyle = .short
        cell.detailTextLabel?.text = Time.string(from: note.lastUpdated)
        
        return cell
    }
    
    //handles when the user select a note from tableview
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        
        let selectedNote = notes[indexPath.row]
        performSegue(withIdentifier: "showNote", sender: selectedNote)
    }
    

    // the user can delete their notes by swipe
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            notes.remove(at: indexPath.row)
            
            // Encode notes array to JSON and save to Userdefaults
            let encoder = JSONEncoder()
            if let encoded = try? encoder.encode(notes){
                UserDefaults.standard.set(encoded, forKey: "notes")
                
            }
        }
        tableView.deleteRows(at: [indexPath], with: .fade)
    }
    
    
    @IBAction func addBtn(_ sender: UIBarButtonItem) {
        performSegue(withIdentifier: "addNote", sender: self)
    }
    
    // if notes not already exist update it otherwise add as new, Sort notes byt time, Save and reload tableview.
    func saveNote(_ note: Note){
        if let index = notes.firstIndex(where: { $0.title == note.title}) {
            notes[index] = note
        } else {
            notes.append(note)
        }
    
        notes = notes.sorted(by: { $0.lastUpdated > $1.lastUpdated})
        
        let encoder = JSONEncoder()
        if let encoded = try? encoder.encode(notes){
            UserDefaults.standard.set(encoded, forKey: "notes")
        }
        tableview.reloadData()
    }
    
    // load notes
    func loadNotes(){
        if let savedNotesData = UserDefaults.standard.data(forKey: "notes"),
            let savedNotes = try? JSONDecoder().decode([Note].self, from: savedNotesData )
        {
            notes = savedNotes
        }
    }
    
    // for segues
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "addNote" {
            let destinationVC = segue.destination as! NewNoteViewController
            destinationVC.delegate = self
        }
        else if segue.identifier == "showNote" {
            let destinationVC = segue.destination as! NewNoteViewController
            if let selectedNote = sender as? Note {
                destinationVC.note = selectedNote
            }
            destinationVC.delegate = self
        }
    }
}

//
//  NewNoteViewController.swift
//  Note.app
//
//  Created by Rafaat.Al-Badri on 2023-03-16.
//

import UIKit

protocol NewNoteViewControllerDelegate: AnyObject{
    func saveNote(_ note: Note)
}


class NewNoteViewController: UIViewController {
    
    weak var delegate: NewNoteViewControllerDelegate?
    var note: Note?
    @IBOutlet weak var titleTextField: UITextField!
    @IBOutlet weak var textView: UITextView!
    @IBOutlet weak var SaveBtn: UIBarButtonItem!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        //if note is not nil , set title and text
        if let note = note {
            titleTextField.text = note.title
            textView.text = note.text
        }

    }
    
    // unwraps the text, creates a new note,calls "savenote" (protocol), pops the current view.
    @IBAction func saveBtn(_ sender: UIBarButtonItem) {
        guard let title = titleTextField.text, let text = textView.text else {
            return
        }
        let note = Note(title: title, text: text, lastUpdated: Date())
        delegate?.saveNote(note)
        navigationController?.popViewController(animated: true)
    }
    

}
